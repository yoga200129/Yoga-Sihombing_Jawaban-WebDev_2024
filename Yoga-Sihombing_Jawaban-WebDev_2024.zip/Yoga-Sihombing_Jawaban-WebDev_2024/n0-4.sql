SELECT 
  e.id AS 'ID employee', 
  e.name AS 'Name employee', 
  d.name AS 'Name department' 
FROM 
  employees e 
  JOIN departments d ON e.department_id = d.id 
ORDER BY 
  e.id ASC;
