<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Departments
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="flex flex-col">
                    <div class="overflow-x-auto">
                        <div class="inline-block min-w-full">
                            <div class="overflow-hidden">
                                <table class="min-w-full divide-y divide-neutral-200">
                                    <thead>
                                        <tr class="text-neutral-500">
                                            <th class="px-5 py-3 text-xs font-medium text-left uppercase">Name</th>
                                            <th class="px-5 py-3 text-xs font-medium text-left uppercase">Creation</th>
                                            <th class="px-5 py-3 text-xs font-medium text-left uppercase">Last Update</th>
                                            <th class="px-5 py-3 text-xs font-medium text-right uppercase">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-neutral-200">
                                        @foreach ($departments as $department)
                                        <tr class="text-neutral-800">
                                            <td class="px-5 py-4 text-sm whitespace-nowrap">
                                                {{ $department->name }}
                                            </td>
                                            <td class="px-5 py-4 text-sm whitespace-nowrap">
                                                {{ $department->created_at->isoFormat('DD MMMM YYYY') }}
                                            </td>
                                            <td class="px-5 py-4 text-sm whitespace-nowrap">
                                                {{ $department->updated_at->isoFormat('DD MMMM YYYY') }}
                                            </td>
                                            <td class="px-5 py-4 text-sm font-medium text-right whitespace-nowrap">
                                                <a class="text-blue-600 hover:text-blue-700" href="#">Edit</a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</x-app-layout>
