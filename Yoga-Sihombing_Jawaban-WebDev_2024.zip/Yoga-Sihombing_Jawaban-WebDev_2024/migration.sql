CREATE TABLE `users`
  (
     `id`                BIGINT UNSIGNED NOT NULL auto_increment PRIMARY KEY,
     `name`              VARCHAR(255) NOT NULL,
     `email`             VARCHAR(255) NOT NULL,
     `email_verified_at` TIMESTAMP NULL,
     `password`          VARCHAR(255) NOT NULL,
     `remember_token`    VARCHAR(100) NULL,
     `created_at`        TIMESTAMP NULL,
     `updated_at`        TIMESTAMP NULL,
     `deleted_at`        TIMESTAMP NULL
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `users`
  ADD UNIQUE `users_email_unique`(`email`);

CREATE TABLE `password_reset_tokens`
  (
     `email`      VARCHAR(255) NOT NULL,
     `token`      VARCHAR(255) NOT NULL,
     `created_at` TIMESTAMP NULL,
     PRIMARY KEY (`email`)
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

CREATE TABLE `sessions`
  (
     `id`            VARCHAR(255) NOT NULL,
     `user_id`       BIGINT UNSIGNED NULL,
     `ip_address`    VARCHAR(45) NULL,
     `user_agent`    TEXT NULL,
     `payload`       LONGTEXT NOT NULL,
     `last_activity` INT NOT NULL,
     PRIMARY KEY (`id`)
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `sessions`
  ADD INDEX `sessions_user_id_index`(`user_id`);

ALTER TABLE `sessions`
  ADD INDEX `sessions_last_activity_index`(`last_activity`);

CREATE TABLE `cache`
  (
     `key`        VARCHAR(255) NOT NULL,
     `value`      MEDIUMTEXT NOT NULL,
     `expiration` INT NOT NULL,
     PRIMARY KEY (`key`)
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

CREATE TABLE `cache_locks`
  (
     `key`        VARCHAR(255) NOT NULL,
     `owner`      VARCHAR(255) NOT NULL,
     `expiration` INT NOT NULL,
     PRIMARY KEY (`key`)
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

CREATE TABLE `jobs`
  (
     `id`           BIGINT UNSIGNED NOT NULL auto_increment PRIMARY KEY,
     `queue`        VARCHAR(255) NOT NULL,
     `payload`      LONGTEXT NOT NULL,
     `attempts`     TINYINT UNSIGNED NOT NULL,
     `reserved_at`  INT UNSIGNED NULL,
     `available_at` INT UNSIGNED NOT NULL,
     `created_at`   INT UNSIGNED NOT NULL
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `jobs`
  ADD INDEX `jobs_queue_index`(`queue`);

CREATE TABLE `job_batches`
  (
     `id`             VARCHAR(255) NOT NULL,
     `name`           VARCHAR(255) NOT NULL,
     `total_jobs`     INT NOT NULL,
     `pending_jobs`   INT NOT NULL,
     `failed_jobs`    INT NOT NULL,
     `failed_job_ids` LONGTEXT NOT NULL,
     `options`        MEDIUMTEXT NULL,
     `cancelled_at`   INT NULL,
     `created_at`     INT NOT NULL,
     `finished_at`    INT NULL,
     PRIMARY KEY (`id`)
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

CREATE TABLE `failed_jobs`
  (
     `id`         BIGINT UNSIGNED NOT NULL auto_increment PRIMARY KEY,
     `uuid`       VARCHAR(255) NOT NULL,
     `connection` TEXT NOT NULL,
     `queue`      TEXT NOT NULL,
     `payload`    LONGTEXT NOT NULL,
     `exception`  LONGTEXT NOT NULL,
     `failed_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `failed_jobs`
  ADD UNIQUE `failed_jobs_uuid_unique`(`uuid`);

CREATE TABLE `departments`
  (
     `id`         BIGINT UNSIGNED NOT NULL auto_increment PRIMARY KEY,
     `name`       VARCHAR(50) NOT NULL,
     `created_at` TIMESTAMP NULL,
     `updated_at` TIMESTAMP NULL,
     `deleted_at` TIMESTAMP NULL
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

CREATE TABLE `employees`
  (
     `id`            BIGINT UNSIGNED NOT NULL auto_increment PRIMARY KEY,
     `name`          VARCHAR(50) NOT NULL,
     `department_id` BIGINT UNSIGNED NOT NULL,
     `created_at`    TIMESTAMP NULL,
     `updated_at`    TIMESTAMP NULL,
     `deleted_at`    TIMESTAMP NULL
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `employees`
  ADD CONSTRAINT `employees_department_id_foreign` FOREIGN KEY (`department_id`)
  REFERENCES `departments` (`id`) ON DELETE CASCADE;

CREATE TABLE `spendings`
  (
     `id`          BIGINT UNSIGNED NOT NULL auto_increment PRIMARY KEY,
     `employee_id` BIGINT UNSIGNED NOT NULL,
     `date`        DATE NOT NULL,
     `value`       INT NOT NULL,
     `created_at`  TIMESTAMP NULL,
     `updated_at`  TIMESTAMP NULL,
     `deleted_at`  TIMESTAMP NULL
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `spendings`
  ADD CONSTRAINT `spendings_employee_id_foreign` FOREIGN KEY (`employee_id`)
  REFERENCES `employees` (`id`) ON DELETE CASCADE;

CREATE TABLE `permissions`
  (
     `id`         BIGINT UNSIGNED NOT NULL auto_increment PRIMARY KEY,
     `name`       VARCHAR(255) NOT NULL,
     `guard_name` VARCHAR(255) NOT NULL,
     `created_at` TIMESTAMP NULL,
     `updated_at` TIMESTAMP NULL
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `permissions`
  ADD UNIQUE `permissions_name_guard_name_unique`(`name`, `guard_name`);

CREATE TABLE `roles`
  (
     `id`         BIGINT UNSIGNED NOT NULL auto_increment PRIMARY KEY,
     `name`       VARCHAR(255) NOT NULL,
     `guard_name` VARCHAR(255) NOT NULL,
     `created_at` TIMESTAMP NULL,
     `updated_at` TIMESTAMP NULL
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `roles`
  ADD UNIQUE `roles_name_guard_name_unique`(`name`, `guard_name`);

CREATE TABLE `model_has_permissions`
  (
     `permission_id` BIGINT UNSIGNED NOT NULL,
     `model_type`    VARCHAR(255) NOT NULL,
     `model_id`      BIGINT UNSIGNED NOT NULL,
     PRIMARY KEY ( `permission_id`, `model_id`, `model_type` )
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `model_has_permissions`
  ADD INDEX `model_has_permissions_model_id_model_type_index`(`model_id`,
  `model_type`);

ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (
  `permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

CREATE TABLE `model_has_roles`
  (
     `role_id`    BIGINT UNSIGNED NOT NULL,
     `model_type` VARCHAR(255) NOT NULL,
     `model_id`   BIGINT UNSIGNED NOT NULL,
     PRIMARY KEY ( `role_id`, `model_id`, `model_type` )
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `model_has_roles`
  ADD INDEX `model_has_roles_model_id_model_type_index`(`model_id`, `model_type`
  );

ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`)
  REFERENCES `roles` (`id`) ON DELETE CASCADE;

CREATE TABLE `role_has_permissions`
  (
     `permission_id` BIGINT UNSIGNED NOT NULL,
     `role_id`       BIGINT UNSIGNED NOT NULL,
     PRIMARY KEY (`permission_id`, `role_id`)
  ) DEFAULT CHARACTER SET utf8mb4 COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (
  `permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`)
  REFERENCES `roles` (`id`) ON DELETE CASCADE;

DELETE FROM `cache`
WHERE  `key` IN
       ( 'spatie.permission.cache',
                  'illuminate:cache:flexible:created:spatie.permission.cache' ); 
