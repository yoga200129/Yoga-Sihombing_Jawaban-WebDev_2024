<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $adminRole = Role::where('name', 'admin')->first();
        $userRole = Role::where('name', 'user')->first();

        User::create(self::prepareData(self::$admin))->assignRole($adminRole);
        foreach (self::$users as $user) {
            User::create(self::prepareData($user))->assignRole($userRole);
        }
    }

    private static function prepareData(array $data): array
    {
        $data['password'] = bcrypt($data['password']);
        $data['email_verified_at'] = now();
        $data['created_at'] = now();
        $data['updated_at'] = now();
        return $data;
    }

    private static $admin = [
        'name' => 'Administrator',
        'email' => 'admin@pgas.com',
        'password' => 'admin',
    ];

    private static $users = [
        [
            'name' => 'Yoga Sihombing',
            'email' => 'yoga@pgas.com',
            'password' => 'akuyoga',
        ],
        [
            'name' => 'Windah Basudara',
            'email' => 'windah@pgas.com',
            'password' => 'akuwindah',
        ],
    ];
}
