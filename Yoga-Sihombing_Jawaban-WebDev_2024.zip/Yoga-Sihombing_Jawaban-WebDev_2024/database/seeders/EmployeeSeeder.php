<?php

namespace Database\Seeders;

use App\Models\Employee;
use Illuminate\Database\Seeder;

class EmployeeSeeder extends Seeder
{
    public function run(): void
    {
        foreach (self::$employees as $employee) {
            $employee['created_at'] = now();
            $employee['updated_at'] = now();
            Employee::create($employee);
        }
    }

    private static $employees = [
        ['name' => 'Budi', 'department_id' => 1],
        ['name' => 'Iwan', 'department_id' => 2],
        ['name' => 'Susi', 'department_id' => 3],
        ['name' => 'Amir', 'department_id' => 1],
        ['name' => 'Primus', 'department_id' => 1],
        ['name' => 'Tuti', 'department_id' => 2],
        ['name' => 'Sinta', 'department_id' => 2],
        ['name' => 'Santi', 'department_id' => 3],
        ['name' => 'Badu', 'department_id' => 3],
        ['name' => 'Marfu\'ah', 'department_id' => 3],
    ];
}
