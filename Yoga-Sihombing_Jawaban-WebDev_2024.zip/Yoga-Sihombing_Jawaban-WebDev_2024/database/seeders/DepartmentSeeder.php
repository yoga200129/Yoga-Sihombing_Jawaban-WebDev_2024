<?php

namespace Database\Seeders;

use App\Models\Department;
use Illuminate\Database\Seeder;

class DepartmentSeeder extends Seeder
{
    public function run(): void
    {
        foreach (self::$departments as $department) {
            Department::create([
                'name' => $department,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }

    private static $departments = [
        'Information Technology',
        'Human Capital',
        'Finance & Accounting',
    ];
}
