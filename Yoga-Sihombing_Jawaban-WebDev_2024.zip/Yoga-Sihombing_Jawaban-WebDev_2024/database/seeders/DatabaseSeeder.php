<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call(self::$seders);
    }

    private static $seders = [
        RolePermissionSeeder::class,
        UserSeeder::class,
        DepartmentSeeder::class,
        EmployeeSeeder::class,
        SpendingSeeder::class,
    ];
}
