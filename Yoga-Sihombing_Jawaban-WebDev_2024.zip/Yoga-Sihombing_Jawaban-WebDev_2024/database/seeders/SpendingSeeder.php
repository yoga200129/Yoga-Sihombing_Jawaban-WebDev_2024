<?php

namespace Database\Seeders;

use App\Models\Spending;
use Illuminate\Database\Seeder;

class SpendingSeeder extends Seeder
{
    public function run(): void
    {
        foreach (self::$spendings as $spending) {
            $spending['created_at'] = now();
            $spending['updated_at'] = now();
            Spending::create($spending);
        }
    }

    private static $spendings = [
        ['employee_id' => 1, 'date' => '2020-03-04', 'value' => 3_000_000],
        ['employee_id' => 4, 'date' => '2020-04-06', 'value' => 9_826_000],
        ['employee_id' => 5, 'date' => '2020-04-06', 'value' => 43_879_200],
        ['employee_id' => 4, 'date' => '2020-09-08', 'value' => 8_983_400],
        ['employee_id' => 6, 'date' => '2020-10-06', 'value' => 2_425_600],
        ['employee_id' => 7, 'date' => '2021-04-02', 'value' => 879_200],
        ['employee_id' => 2, 'date' => '2021-04-02', 'value' => 68_892_340],
        ['employee_id' => 3, 'date' => '2021-05-01', 'value' => 3_500_000],
        ['employee_id' => 3, 'date' => '2021-07-03', 'value' => 567_800],
        ['employee_id' => 4, 'date' => '2021-07-03', 'value' => 6_786_730],
        ['employee_id' => 8, 'date' => '2021-08-02', 'value' => 7_893_400],
        ['employee_id' => 3, 'date' => '2021-10-03', 'value' => 8_200_450],
        ['employee_id' => 1, 'date' => '2021-12-23', 'value' => 8_982_300],
        ['employee_id' => 2, 'date' => '2022-02-03', 'value' => 334_890],
        ['employee_id' => 5, 'date' => '2022-04-06', 'value' => 2_342_460],
        ['employee_id' => 2, 'date' => '2022-04-11', 'value' => 78_923_400],
        ['employee_id' => 6, 'date' => '2022-11-05', 'value' => 23_244_600],
        ['employee_id' => 3, 'date' => '2022-11-05', 'value' => 32_324_900],
        ['employee_id' => 6, 'date' => '2023-01-03', 'value' => 5_500_100],
        ['employee_id' => 5, 'date' => '2023-03-27', 'value' => 2_342_350],
        ['employee_id' => 5, 'date' => '2023-04-02', 'value' => 2_423_400],
    ];
}
