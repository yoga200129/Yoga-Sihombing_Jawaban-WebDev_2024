<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        $userPermissions = array_merge(self::$createPermissions, self::$readPermissions);
        $allPermissions = array_merge(
            $userPermissions,
            self::$updatePermissions,
            self::$deletePermissions
        );

        foreach ($allPermissions as $permission) {
            Permission::create([
                'name' => $permission,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        Role::create(['name' => 'admin'])->givePermissionTo($allPermissions);
        Role::create(['name' => 'user'])->givePermissionTo($userPermissions);
    }

    private static $createPermissions = [
        'create department',
        'create employee',
        'create spending',
    ];

    private static $readPermissions = [
        'read department',
        'read employee',
        'read spending',
    ];

    private static $updatePermissions = [
        'update department',
        'update employee',
        'update spending',
    ];

    private static $deletePermissions = [
        'delete department',
        'delete employee',
        'delete spending',
    ];
}
